package ch05;

public class MainTest1 {

	public static void main(String[] args) {
		new MyImageFrame4();

	}

}
