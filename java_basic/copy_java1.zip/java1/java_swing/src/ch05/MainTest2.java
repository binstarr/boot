package ch05;

public class MainTest2 {

	public static void main(String[] args) {
		new MyFrame6();

	}

}
