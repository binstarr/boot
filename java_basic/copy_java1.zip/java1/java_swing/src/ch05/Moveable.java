package ch05;

public interface Moveable {

	void left();
	void right();
	void up();
	void down();
	
}
