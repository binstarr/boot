package ch01;

public class MainTest1 {

	public static void main(String[] args) {
		
		//	MyFrame myFrame1 = new MyFrame();
		new MyFrame();
		
		

	}

}
