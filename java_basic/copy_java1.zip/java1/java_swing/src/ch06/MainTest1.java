package ch06;

public class MainTest1 {

	public static void main(String[] args) {
//		new MyFrame07();
//		new MyImageFrame();
		new MiniGame();

	}

}
