package ch06;


public class Lotto {

	
	public Lotto() {
		
	}
	
	public void lottoNumber(){
		
	}
	
}
