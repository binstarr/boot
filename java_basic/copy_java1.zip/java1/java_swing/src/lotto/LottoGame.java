package lotto;

public class LottoGame {
	
	LottoFrame mainFrame = new LottoFrame();
	
	public static void main(String[] args) {
		new LottoFrame();

	}

}
