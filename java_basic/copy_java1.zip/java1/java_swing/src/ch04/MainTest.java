package ch04;

public class MainTest {

	public static void main(String[] args) {
		new MyFrame1();

	}

}
