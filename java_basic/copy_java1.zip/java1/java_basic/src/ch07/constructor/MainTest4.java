package ch07.constructor;

public class MainTest4 {

	public static void main(String[] args) {
		

	}

}
