package ch05;

public class UserInfo {

	String userId; // 식별자
	String userPassword;
	String userName;
	String userAddress;
	int phoneNumber;
	
	
	/*
	 * 클래스는 대문자로 시작한다.
	 * 하나의 자바 파일에 클래스를 여러개 만들 수 있다. 단 public 클래스는 단 하나 이어야 한다. (약속)
	 * camel notation 방식으로 명명 하는게 좋다.
	 * 
	 */
}

	 class School{
		String name;
	}
