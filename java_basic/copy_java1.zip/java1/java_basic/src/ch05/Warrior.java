package ch05;

public class Warrior {
	
	// 상태 (속성)
	String name;
	int height;
	int power;
	String color;
	
	// 행위 (기능)

	
}

// 전사라는 클래스를 설계