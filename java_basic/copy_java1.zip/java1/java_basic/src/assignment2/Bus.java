package assignment2;

public class Bus extends Ride{

	public Bus(String name) {
		this.name = name;
		this.destination = "서울";
		this.takeTime = 6;	
	}
}
