//package assignment2;
//
//import java.util.Random;
//
//public class LottoMainTest {
//
//	public static void main(String[] args) {
//		
//		int lottoNumber = 0;
//		int[] lotto = new int[7];
//		int[] lottoIn = new int[6];
//		Random random = new Random();
//		
//		lottoNumber = random.nextInt(45) + 1;
//		System.out.println(lottoNumber);
//		
//		for(int i = 0; i < lotto.length; i++) {
//			lotto[i] = random.lottoNum(lotto);
//			System.out.print(lotto[i] + " ");
//		}
//		System.out.println();
//		
//		System.out.println("로또번호 입력(띄어쓰기로 구분)");
//		for(int i =0; i < rottoInput.length; i++) {
//			rottoInput[i] = scanner.nextInt();
//		}
//
//	}
//
//}
