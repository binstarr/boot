package assignment2;

public class MyNoteBook extends NoteBook {
	
	@Override
	public void display() {
		System.out.println("나의 노트북");
	}
}
