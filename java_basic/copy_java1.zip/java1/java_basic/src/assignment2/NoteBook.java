package assignment2;

public abstract class NoteBook extends Computer{

	
	public void typing() {
		System.out.println("노트북 타자를 칩니다.");
	}
}
