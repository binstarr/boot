package assignment2;

public class Airplane extends Ride {

	public Airplane(String name) {
		this.name = name;
		this.destination = "서울";
		this.takeTime = 1;
	}
}
