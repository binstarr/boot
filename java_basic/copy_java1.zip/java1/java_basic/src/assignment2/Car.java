package assignment2;

public class Car extends Ride{

	public Car(String name) {
		this.name = name;
		this.destination = "서울";
		this.takeTime = 8;	
	}
}
