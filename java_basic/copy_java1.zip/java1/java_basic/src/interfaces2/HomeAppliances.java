package interfaces2;

public abstract class HomeAppliances {

	
	
	
}