package interfaces2;

public interface SoundImpact {
	
	public abstract void touchButton();
}
