package generic_ex.ch03;

public abstract class Material {

	public abstract void doPrinting();
	
	
}
