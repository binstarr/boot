package generic_ex.ch01;

public class ThreedPrinter1 {

	// 재료
	private Powder material;

	public Powder getMaterial() {
		return material;
	}

	public void setMaterial(Powder material) {
		this.material = material;
	}

} // end of class
