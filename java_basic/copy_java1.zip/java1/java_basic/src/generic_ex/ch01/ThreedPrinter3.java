package generic_ex.ch01;

public class ThreedPrinter3 {

	// 플라스틱, 파우더
	private Object material;

	public Object getMaterial() {
		return material;
	}

	public void setMaterial(Object material) {
		this.material = material;
	}
	
}
