package generic_ex.ch01;

public class Powder {

	@Override
	public String toString() {
		return "재료는 Powder 입니다.";
	}
	
} // end of class
