package wrapper_ex;

public enum Fruit {
	APPLE, BANANA, GRAPE
}
