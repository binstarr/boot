package wrapper_ex;

public enum Medal {
	GOLD, SILVER, BRONZE
}
