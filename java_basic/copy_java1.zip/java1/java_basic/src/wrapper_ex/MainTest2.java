package wrapper_ex;

public class MainTest2 {

	public static void main(String[] args) {
		
//		Integer num = new Integer(17);
		Integer num = 17; // 자동 박싱
		int n = num; // 자동 언박싱
		
		System.out.println(n);

	}

}
