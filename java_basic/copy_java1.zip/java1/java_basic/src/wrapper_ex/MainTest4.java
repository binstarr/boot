package wrapper_ex;

public class MainTest4 {

	public static void main(String[] args) {
		
		int number = 10;

//		String temp = number + "";
		String temp = String.valueOf(number);
		System.out.println(temp);
	}

}
