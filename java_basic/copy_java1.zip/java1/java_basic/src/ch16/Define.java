package ch16;

public class Define {

	public static final int MAX = 9999;
	public static final int MIN = 1;
	public static final double PI = 3.14;
	public static final String APPNAME = "부트캠프";
	public static final int MATH_CODE = 1001;
	
}
