package ch09;

public class HeroMainTest {

	public static void main(String[] args) {
		
		Hero hero = new Hero();
		Hero hero2 = new Hero();
		hero.setName("홍");
		hero.setLevel(1);
		
		
	
		

	}

}
