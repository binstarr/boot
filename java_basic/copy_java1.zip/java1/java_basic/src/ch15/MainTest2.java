package ch15;

public class MainTest2 {

	public static void main(String[] args) {
		
		// 객체 지향 패러다임 관점으로
		// Animal animal = new Animal(); 직접 new 메모리 올리는 과정을 막아 버린다
		
		// Hero () -> abstract 키워드를 사용해서 직접 존재하는 것을 막아 버린다.
		// 롤 : 야스오, 애쉬, 티모()
		
	}
}
