package ch15;

public class Peach extends Fruit{

	public Peach() {
		name = "복숭아";
		price = 5_000;
		fresh = 100;
	}
	
}
