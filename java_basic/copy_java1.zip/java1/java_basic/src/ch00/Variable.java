package ch00;

public class Variable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
