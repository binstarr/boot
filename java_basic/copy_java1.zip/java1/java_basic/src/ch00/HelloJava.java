package ch00;

public class HelloJava {

	// main (프로그래밍에 시작점)
	public static void main(String[] args) {
		
		System.out.println("Hello Java");
		// 주석 : 자바에서 명령어에 마지막은 세미콜론으로 마무리 한다.
	} // <-- 블록(중괄호)
	// 블록에 범위는 절대적입니다. (자바에서)
}
