package com.boot.company;

public class MainTest {

	public static void main(String[] args) {
		
		// 스캐너로 사용자 값 받아서 담기도 가능. (해보기) 
		UserInfo info = new UserInfo("1", "123", "홍길동");
		IUserInfoDao infoDao;
//		infoDao.insertUserInfo(info);

	}

}
