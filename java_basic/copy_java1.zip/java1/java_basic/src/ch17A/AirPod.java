package ch17A;

public class AirPod extends Product{
	
	public AirPod() {
		name = "에어팟";
	}

}
