package ch17A;

public abstract class Product {

	String name;
	
	public void showInfo() {
		System.out.println("상품 명 : " + name);
	}
	
}
