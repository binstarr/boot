package ch17A;

public class TeddyBear extends Product{

	public TeddyBear() {
			
	}
	
	
}
