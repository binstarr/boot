package interfaces;

public class ToyRobot{

	String name;
	
	public void turnOn() {
		System.out.println("장난감 로봇을 켭니다.");
	}
	
	public void turnOff() {
		System.out.println("장난감 로봇을 끕니다.");
	}
	
}
