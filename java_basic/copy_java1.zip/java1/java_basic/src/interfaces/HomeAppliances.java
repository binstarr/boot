package interfaces;

public abstract class HomeAppliances {

	int width;
	int height;
	String color;
	
	public abstract void turnOn();
	
	public abstract void turnOff();
	
}
