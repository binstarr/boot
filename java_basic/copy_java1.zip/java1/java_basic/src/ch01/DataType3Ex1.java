package ch01;

public class DataType3Ex1 {

	public static void main(String[] args) {
		// 변수 : 기본 데이터 타입, 참조 자료형
		// 실수형 : 1. float, 2. double
		
		float a = 0.5F; // 접미사 사용
		float b = 0.1f;
		
		double c = 0.12345; // 실수형에 기본 연산 단위는 double이다.
		double d = 1.12345; // 8byte
		
		// 소수점을 많이 표시할 수 있기 때문에 정확성을 더 보장한다.
		
	}// end of main

}// end of class
