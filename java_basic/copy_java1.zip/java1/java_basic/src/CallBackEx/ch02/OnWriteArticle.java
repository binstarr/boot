package CallBackEx.ch02;

// MyArticle 클래스와 HackerNews클래스에 약속으로 사용할 예정 !!!
public interface OnWriteArticle {
	void printNews(String article);
}
