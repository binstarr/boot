package Starcraft2;

public class GateWayMainTest2 {

	public static void main(String[] args) {
		
		// 배열이란
		// 연관된 데이터를 통으로 모아서 관리하기 위해 사용하는 데이터 타입
		// 모든 프로그램에서 인덱스 값에 시작은 0부터 시작한다.
		
		// 인덱스 공식 n - 1
		// 인덱스에 크기는(길이) n
		// 배열의 크기 10
		// 인덱스의 길이 9
		
		int[] intArr = new int[10]; // 1   <--- 권장
		int intArr2[] = new int[5]; // 2
	
		
		int[] intArr3 = new int[47]; // 배열에 크기는 47, 인덱스에 크기는 46
		int[] intArr4 = new int[776]; // 배열에 크기는 776, 인덱스에 크기는 775
		

	}

}
