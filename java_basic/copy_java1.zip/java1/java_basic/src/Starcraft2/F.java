package Starcraft2;

public class F {
	
	G g;
	
	public F() {
		System.out.println(" F 클래스를 메모리에 올려서 객체화 했습니다.");
		g = new G();
	}
	
}
