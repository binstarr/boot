package Starcraft2;

public class ArrayTest1 {

	public static void main(String[] args) {
		
		// 마린, 저글링 배열선언(참조 타입)
		Marine[] marine = new Marine[2];
		// 정수배열 (기본데이터 타입)
		
		// 1. 배열 사용해서 객체를 생성하고 주소값들을 통으로 메모리
		// 2. 스캐너 사용해서 값에 따라서 객체들 동작 시켜 보세요
		
		// 1. 메모리 객체 질럿 3 올라가 있다.
		
		// 2. 스캐너를 사용해서 1 2 3 - 선택해서 공격을 할 수 있도록 설계

	}

}
