package Starcraft2;

public class C {
	D d;
	
	public C() {
		System.out.println("C 클래스를 메모리에 올려서 객체화 했습니다.");
		d = new D();
	}
}
