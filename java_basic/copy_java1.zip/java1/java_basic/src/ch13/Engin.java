package ch13;

public class Engin {
	
	String name;
	int price;
	
public Engin(String name, int price) {
	this.name = name;
	this.price = price;
}	

}
