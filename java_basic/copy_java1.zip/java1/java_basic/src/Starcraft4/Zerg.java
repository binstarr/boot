package Starcraft4;

public interface Zerg {
	
	public abstract void attack(Unit unit);

}
