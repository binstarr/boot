package Starcraft4;

public interface Terran {

	public abstract void attack(Unit unit);
}
