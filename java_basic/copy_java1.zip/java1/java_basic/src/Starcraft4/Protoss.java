package Starcraft4;

public interface Protoss {	
//	public abstract void attack(Zealot zealot);
//	public abstract void attack(Marine zealot);
//	public abstract void attack(Zergling zealot);

	public abstract void attack(Unit unit);
	
}
