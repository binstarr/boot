package main;

import frame.MainFrame;

public class MainClass {

	public static void main(String[] args) {
		new MainFrame();
	}

}
