package test.ex07;

public enum PlayerWay {
	LEFT,RIGHT

}
