package test.ex08;

public enum PlayerWay {
	LEFT,RIGHT

}
