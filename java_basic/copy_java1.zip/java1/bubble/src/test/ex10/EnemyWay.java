package test.ex10;

public enum EnemyWay {
	LEFT,RIGHT
}
