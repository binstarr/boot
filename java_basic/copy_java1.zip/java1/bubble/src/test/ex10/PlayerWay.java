package test.ex10;

public enum PlayerWay {
	LEFT,RIGHT

}
