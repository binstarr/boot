package game.state;

public enum EnemyWay {
	LEFT,RIGHT
}
