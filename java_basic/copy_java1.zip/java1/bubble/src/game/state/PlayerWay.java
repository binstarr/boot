package game.state;

public enum PlayerWay {
	LEFT,RIGHT

}
